package ocean.inventoryprotection.common.world.item;

import net.minecraft.core.component.DataComponents;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;
import ocean.inventoryprotection.common.config.ApplicationConfig;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.List;

/**
 * 保护符
 *
 * @author zhang
 * @since 2023/1/14
 */
public class Protector extends Item {

    public Protector() {
        super(new Properties());
    }

    @Override
    public void appendHoverText(ItemStack itemStack, TooltipContext p_339594_, List<Component> components, TooltipFlag p_41424_) {
        for (String lore : ApplicationConfig.LORE.get()) {
            components.add(Component.literal(lore));
        }
    }

    @Override
    public @NotNull Component getName(@NotNull ItemStack stack) {
        String custom = ApplicationConfig.DIS_PLAYER_NAME.get();
        return custom.isEmpty()
                ? super.getName(stack)
                : Component.literal(custom);
    }

    @Override
    public @NotNull ItemStack getDefaultInstance() {
        ItemStack stack = super.getDefaultInstance();
        stack.set(DataComponents.CUSTOM_NAME, Component.literal(ApplicationConfig.DIS_PLAYER_NAME.get()));
        return stack;
    }
}
