package ocean.inventoryprotection.common.event;

import net.minecraft.core.HolderLookup;
import net.minecraft.core.NonNullList;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.nbt.Tag;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ArmorItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.ShieldItem;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.entity.living.LivingDropsEvent;
import net.neoforged.neoforge.event.entity.living.LivingExperienceDropEvent;
import net.neoforged.neoforge.event.entity.player.PlayerEvent;
import ocean.InventoryProtection;
import ocean.inventoryprotection.common.ModItems;
import ocean.inventoryprotection.common.config.ApplicationConfig;

import java.util.Collection;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

@EventBusSubscriber(modid = InventoryProtection.MODID)
public class ModEvents {

    private static final String APPLICATION_NAME = "InventoryProtection_playerInventoryDrops";
    private static final String DROP_COUNT = "dropSize";
    private static final String DROP_PREFIX = "dropPrefix";
    private static final String DROP_LEVEL_POINT = "dropLevelPoint";

    @SubscribeEvent
    public static void onLivingDropsEvent(LivingDropsEvent event) {
        if (event.getEntity() instanceof Player player && container(ModItems.PROTECTOR.get(), event.getDrops())) {
            HolderLookup.Provider lookupProvider = event.getEntity().registryAccess();
            List<ItemEntity> drops = event.getDrops().stream().map(res -> {
                if (!res.getItem().isEmpty()) {
                    return res;
                }
                return null;
            }).filter(Objects::nonNull).toList();
            if (!drops.isEmpty()) {
                event.getDrops().removeAll(drops);
                CompoundTag cmp = new CompoundTag();
                for (int i = 0; i < drops.size(); i++) {
                    ItemStack stack = drops.get(i).getItem();
                    Tag serialized = stack.save(lookupProvider);
                    if (serialized instanceof CompoundTag tagItem) {
                        cmp.put(DROP_PREFIX + i, tagItem);
                    }
                }
                CompoundTag data = event.getEntity().getPersistentData();
                if (!data.contains(Player.PERSISTED_NBT_TAG)) {
                    data.put(Player.PERSISTED_NBT_TAG, new CompoundTag());
                }
                cmp.putInt(DROP_COUNT, drops.size());
                cmp.putInt(DROP_LEVEL_POINT, player.totalExperience);
                CompoundTag persist = data.getCompound(Player.PERSISTED_NBT_TAG);
                persist.put(APPLICATION_NAME, cmp);
            }
        }
    }

    @SubscribeEvent
    public static void onLivingExperienceDropEvent(LivingExperienceDropEvent event) {
        if (ApplicationConfig.LEVEL.get() && event.getEntity().getPersistentData().contains(Player.PERSISTED_NBT_TAG)) {
            event.setCanceled(true);
        }
    }

    @SubscribeEvent
    public static void onPlayerRespawn(PlayerEvent.PlayerRespawnEvent event) {
        Player player = event.getEntity();
        CompoundTag data = player.getPersistentData();
        if (data.contains(Player.PERSISTED_NBT_TAG)) {
            CompoundTag inventoryIndex = data.getCompound(Player.PERSISTED_NBT_TAG);
            CompoundTag allDrops = inventoryIndex.getCompound(APPLICATION_NAME);
            int count = allDrops.getInt(DROP_COUNT);
            if (count > 0) {
                for (int i = 0; i < count; i++) {
                    CompoundTag item = allDrops.getCompound(DROP_PREFIX + i);
                    ItemStack stack = ItemStack.parseOptional(player.level().registryAccess(), item);
                    if (!stack.isEmpty()) {
                        ItemStack copy = stack.copy();
                        if (copy.getItem() == ModItems.PROTECTOR.get()) {
                            copy.shrink(1);
                        }
                        inventoryReset(player, copy);
                    }
                }
                if (ApplicationConfig.LEVEL.get()) {
                    player.giveExperiencePoints(allDrops.getInt(DROP_LEVEL_POINT));
                }
                player.sendSystemMessage(Component.literal(ApplicationConfig.MESSAGE.get()));
            }
            inventoryIndex.remove(APPLICATION_NAME);
        }
    }

    private static void inventoryReset(Player player, ItemStack copy) {
        if (copy.getItem() instanceof ArmorItem) {
            EquipmentSlot equipmentslot = player.getEquipmentSlotForItem(copy);
            if (container(player.getInventory().armor, copy)) {
                addInventory(player, copy);
            } else {
                player.setItemSlot(equipmentslot, copy.copy());
            }
        } else if (copy.getItem() instanceof ShieldItem) {
            EquipmentSlot equipmentslot = player.getEquipmentSlotForItem(copy);
            if (container(player.getInventory().offhand, copy)) {
                addInventory(player, copy);
            } else {
                player.setItemSlot(equipmentslot, copy.copy());
            }
        } else {
            addInventory(player, copy);
        }
    }

    public static void addInventory(Player player, ItemStack itemStack) {
        if (!player.getInventory().add(itemStack)) {
            player.drop(itemStack, true);
        }
    }

    public static boolean container(Item item, Collection<ItemEntity> itemEntities) {
        for (ItemEntity itemEntity : itemEntities) {
            if (itemEntity.getItem().getItem() == item) {
                return true;
            }
        }
        return false;
    }

    public static boolean container(NonNullList<ItemStack> itemStacks, ItemStack itemStack) {
        for (ItemStack stack : itemStacks) {
            if (ItemStack.isSameItem(stack, itemStack)) {
                return true;
            }
        }
        return false;
    }
}
