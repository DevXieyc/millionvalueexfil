package ocean.inventoryprotection.common.config;

import net.neoforged.neoforge.common.ModConfigSpec;

import java.util.ArrayList;
import java.util.List;

/**
 * 配置文件
 *
 * @author zhang
 * @since 2021/11/21
 */
public class ApplicationConfig {

    public static final ModConfigSpec.Builder BUILDER = new ModConfigSpec.Builder();

    public static final ModConfigSpec SPEC;

    /**
     * Lore
     */
    public static final ModConfigSpec.ConfigValue<String> DIS_PLAYER_NAME;

    /**
     * Lore
     */
    public static final ModConfigSpec.ConfigValue<List<String>> LORE;

    /**
     * 复活后发送的消息
     */
    public static final ModConfigSpec.ConfigValue<String> MESSAGE;

    /**
     * 保留经验值
     */
    public static final ModConfigSpec.ConfigValue<Boolean> LEVEL;


    static {
        BUILDER.push("Config for InventoryProtection Mod !");

        LORE = BUILDER.comment("保护符lore").define("lore", new ArrayList<>() {{
            add("§7将此护身符放在背包中");
            add("§7死亡时，你的背包将会受到保护");
            add("§7而不会掉落");
        }});

        DIS_PLAYER_NAME = BUILDER.comment("物品名称").define("disPlayName", "§9灿烂天狼保护符");
        MESSAGE = BUILDER.comment("复活后发送的消息").define("message", "§2你背包中的 §9灿烂天狼保护符 §2已被消耗以激活死亡保护。");
        LEVEL = BUILDER.comment("保留经验值").define("level", false);

        SPEC = BUILDER.build();
    }
}