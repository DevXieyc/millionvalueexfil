package ocean.inventoryprotection.common;

import net.minecraft.world.item.Item;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.neoforge.registries.DeferredRegister;
import ocean.InventoryProtection;
import ocean.inventoryprotection.common.world.item.Protector;

import java.util.function.Supplier;

/**
 * 物品加载
 *
 * @author zhang
 * @since 2021/11/3
 */
public class ModItems {

    public static final DeferredRegister.Items ITEMS = DeferredRegister.createItems(InventoryProtection.MODID);

    /**
     * 保护符
     */
    public static final Supplier<Item> PROTECTOR = ITEMS.register("protector",
            Protector::new);

    public static void register(IEventBus bus) {
        ITEMS.register(bus);
    }
}